
  # Login Page and Product Website

  This is a code bundle for Login Page and Product Website. The original project is available at https://www.figma.com/design/6epezYvm6fwTQivKULB5Ko/Login-Page-and-Product-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  