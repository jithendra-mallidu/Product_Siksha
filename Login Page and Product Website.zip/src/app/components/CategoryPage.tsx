import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Send } from 'lucide-react';
import Navigation from './Navigation';
import { ImageWithFallback } from './figma/ImageWithFallback';

const categoryData: Record<string, {
  title: string;
  timelineImage: string;
  questions: { id: number; text: string; }[];
}> = {
  'product-design': {
    title: 'Product Design',
    timelineImage: 'https://images.unsplash.com/photo-1599586108868-9c37eb5172ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ24lMjB0aGlua2luZyUyMHdoaXRlYm9hcmR8ZW58MXx8fHwxNzY1Njc3Nzk3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'Design a better grocery shopping experience for elderly people.' },
      { id: 2, text: 'How would you improve the YouTube mobile app for content creators?' },
      { id: 3, text: 'Design a product to help people find local community events.' },
    ]
  },
  'product-analytics': {
    title: 'Product Analytics',
    timelineImage: 'https://images.unsplash.com/photo-1748609160056-7b95f30041f0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmFseXRpY3MlMjBkYXRhJTIwZGFzaGJvYXJkfGVufDF8fHx8MTc2NTY3Nzc5N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'Facebook DAU dropped by 10% in a week. What metrics would you look at?' },
      { id: 2, text: 'How would you measure the success of Instagram Reels?' },
      { id: 3, text: 'What metrics would you track for a food delivery app?' },
    ]
  },
  'product-strategy': {
    title: 'Product Strategy',
    timelineImage: 'https://images.unsplash.com/photo-1765438869297-6fa4b627906a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHN0cmF0ZWd5JTIwcGxhbm5pbmd8ZW58MXx8fHwxNzY1NTk3MTQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'Should Uber expand into the food retail business?' },
      { id: 2, text: 'How would you prioritize features for the next quarter?' },
      { id: 3, text: 'What market should Netflix enter next?' },
    ]
  },
  'behavioral-questions': {
    title: 'Behavioral Questions',
    timelineImage: 'https://images.unsplash.com/photo-1739298061707-cefee19941b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFtJTIwY29sbGFib3JhdGlvbiUyMG1lZXRpbmd8ZW58MXx8fHwxNzY1NjQ1MDUwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'Tell me about a time you had to influence without authority.' },
      { id: 2, text: 'Describe a situation where you failed and what you learned.' },
      { id: 3, text: 'How do you handle conflicting priorities from stakeholders?' },
    ]
  },
  'product-execution': {
    title: 'Product Execution',
    timelineImage: 'https://images.unsplash.com/photo-1758876201723-9f050343325c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9qZWN0JTIwZXhlY3V0aW9uJTIwd29ya2Zsb3d8ZW58MXx8fHwxNzY1Njc3Nzk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'How would you launch a new feature for an existing product?' },
      { id: 2, text: 'Walk me through your product development process.' },
      { id: 3, text: 'How do you manage a product roadmap?' },
    ]
  },
  'root-cause-analysis': {
    title: 'Root Cause Analysis',
    timelineImage: 'https://images.unsplash.com/photo-1589568482418-998c3cb2430a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ibGVtJTIwc29sdmluZyUyMGFuYWx5c2lzfGVufDF8fHx8MTc2NTY3Nzc5OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'User engagement dropped 20% overnight. How do you diagnose the issue?' },
      { id: 2, text: 'App crash rate increased by 5x. What would you do?' },
      { id: 3, text: 'Conversion rate suddenly dropped. Investigate the root cause.' },
    ]
  },
  'gtm': {
    title: 'Go-To-Market Strategy',
    timelineImage: 'https://images.unsplash.com/photo-1765533220769-9fd90a9f458f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwbGF1bmNoJTIwbWFya2V0aW5nfGVufDF8fHx8MTc2NTY3Nzc5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    questions: [
      { id: 1, text: 'How would you launch a new SaaS product?' },
      { id: 2, text: 'What is your GTM strategy for entering a new market?' },
      { id: 3, text: 'How would you position a product against established competitors?' },
    ]
  },
};

export default function CategoryPage() {
  const { categoryName } = useParams<{ categoryName: string }>();
  const category = categoryData[categoryName || ''];
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answer, setAnswer] = useState('');
  const [feedback, setFeedback] = useState('');
  const [difficulty, setDifficulty] = useState('all');
  const [topic, setTopic] = useState('all');

  if (!category) {
    return <div>Category not found</div>;
  }

  const currentQuestion = category.questions[currentQuestionIndex];

  const handleSubmit = () => {
    // Simulate AI feedback
    setFeedback(`Great start! Here's some feedback on your answer:

1. **Strengths**: You've demonstrated a good understanding of the problem space and identified key user pain points.

2. **Areas for Improvement**: 
   - Consider adding more specific metrics to measure success
   - Expand on the implementation details
   - Include more stakeholder perspectives

3. **Next Steps**: Try to structure your answer using a framework like CIRCLES or STAR for better clarity.

Keep practicing! Your analytical thinking is strong.`);
  };

  const goToPrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      setAnswer('');
      setFeedback('');
    }
  };

  const goToNext = () => {
    if (currentQuestionIndex < category.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setAnswer('');
      setFeedback('');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation onLogout={onLogout} />
      
      {/* Timeline Image */}
      <div className="relative h-64 bg-gray-900 overflow-hidden">
        <ImageWithFallback
          src={category.timelineImage}
          alt={category.title}
          className="w-full h-full object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <h1 className="text-4xl text-white">{category.title}</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-6">
        <div className="flex gap-6">
          {/* Left Pane - Filters */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <h3 className="mb-4">Filters</h3>
              
              <div className="mb-6">
                <label className="block text-sm mb-2">Difficulty</label>
                <select 
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Levels</option>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm mb-2">Topic</label>
                <select 
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="all">All Topics</option>
                  <option value="consumer">Consumer</option>
                  <option value="b2b">B2B</option>
                  <option value="platform">Platform</option>
                </select>
              </div>
            </div>
          </div>

          {/* Middle Pane - Canvas */}
          <div className="flex-1">
            <div className="bg-white rounded-lg shadow-sm">
              {/* Answer Area */}
              <div className="p-6 border-b border-gray-200">
                <h3 className="mb-4">Your Answer</h3>
                <textarea
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Type your answer here... Use frameworks like CIRCLES, STAR, or custom approaches to structure your response."
                  className="w-full h-80 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              {/* Prompt Input */}
              <div className="p-6">
                <div className="flex gap-3">
                  <input
                    type="text"
                    placeholder="Ask AI for specific feedback or guidance..."
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button 
                    onClick={handleSubmit}
                    className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    Get Feedback
                  </button>
                </div>
              </div>

              {/* AI Feedback */}
              {feedback && (
                <div className="p-6 bg-gray-50 border-t border-gray-200">
                  <h3 className="mb-4">AI Feedback</h3>
                  <div className="prose max-w-none">
                    <pre className="whitespace-pre-wrap text-sm text-gray-700 bg-white p-4 rounded-lg border border-gray-200">
                      {feedback}
                    </pre>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Pane - Question */}
          <div className="w-80 flex-shrink-0">
            <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
              <div className="flex items-center justify-between mb-4">
                <h3>Question {currentQuestionIndex + 1} of {category.questions.length}</h3>
              </div>
              
              <div className="mb-6">
                <p className="text-lg leading-relaxed">
                  {currentQuestion.text}
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={goToPrevious}
                  disabled={currentQuestionIndex === 0}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </button>
                <button
                  onClick={goToNext}
                  disabled={currentQuestionIndex === category.questions.length - 1}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}